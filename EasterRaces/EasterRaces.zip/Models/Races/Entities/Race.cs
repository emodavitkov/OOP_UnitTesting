﻿namespace EasterRaces.Models.Races.Entities
{
    public class Race
    {
        
    }
}