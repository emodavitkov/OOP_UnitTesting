﻿namespace EasterRaces.Repositories.Entities
{
    public class CarRepository
    {
        
    }
}