﻿using System;
using System.Collections.Generic;
using Bakery.Models.BakedFoods.Contracts;
using Bakery.Models.Drinks.Contracts;
using Bakery.Models.Tables.Contracts;
using Bakery.Utilities.Messages;

namespace Bakery.Models.Tables
{
    public abstract class Table:ITable
    {
        private List<IBakedFood> bakedFood;
        private List<IDrink> drinks;
        private int capacity;
        private int numberOfPeople;

        public Table(int tableNumber, int capacity, decimal pricePerPerson)
        {
            
            this.bakedFood = new List<IBakedFood>();
            this.drinks = new List<IDrink>();
            this.Capacity = capacity;
            TableNumber=tableNumber;
        }

        public int TableNumber { get; private set; }
        

        public int Capacity
        {
            get
            {
                return this.capacity;
            }
            private set
            {
                if (value < 0)
                {
                    throw new ArgumentException(ExceptionMessages.InvalidTableCapacity);
                }

                this.capacity = value;
            }
        }
      

        public int NumberOfPeople
        {
            get
            {
                return this.numberOfPeople;
            }
            private set
            {
                if (value <= 0)
                {
                    throw new ArgumentException(ExceptionMessages.InvalidNumberOfPeople);
                }

                this.numberOfPeople = value;
            }
        }
        public decimal PricePerPerson { get; private set; }
        public bool IsReserved { get; private set; }

        public decimal Price
        {
            get
            {
                return PricePerPerson * NumberOfPeople;
            }
        }
        public void Reserve(int numberOfPeople)
        {
            IsReserved = true;
            NumberOfPeople = numberOfPeople;
        }

        public void OrderFood(IBakedFood food)
        {
            this.bakedFood.Add(food);
        }

        public void OrderDrink(IDrink drink)
        {
            this.drinks.Add(drink);
        }

        public decimal GetBill()
        {
            decimal bill = 0;
            foreach (var food in bakedFood)
            {
                bill += food.Price;
            }

            foreach (var drink in drinks)
            {
                bill += drink.Price;
            }

            return bill;
        }

        public void Clear()
        {
            bakedFood.Clear();
            drinks.Clear();
            NumberOfPeople = 0;
            IsReserved=false;
        }

        public string GetFreeTableInfo()
        {
            return $"Table: {TableNumber}:\r\n"+
            $"Type: {this.GetType().Name}\r\n" +
            $"Capacity: {Capacity}\r\n" + 
            $"Price per Person: {PricePerPerson}";

        }
    }
}